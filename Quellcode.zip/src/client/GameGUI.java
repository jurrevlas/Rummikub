package client;

import javax.swing.JPanel;
import java.awt.BorderLayout;

public class GameGUI extends JPanel {

	/**
	 * Create the panel.
	 */
	public GameGUI() {
		setLayout(new BorderLayout(0, 0));

	}

}
